
import React from 'react';

export default function AgentLoaderPopup() {
  return <div className="loading">🔄 Wechsle Agent...</div>;
}
