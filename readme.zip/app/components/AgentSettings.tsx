
import React from 'react';

export default function AgentSettings() {
  return <div>Agent Settings UI (Dropdown etc.)</div>;
}
