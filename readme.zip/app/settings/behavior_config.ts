import config from './default_config.json'

export async function getBehaviorConfig() {
  return config;
}